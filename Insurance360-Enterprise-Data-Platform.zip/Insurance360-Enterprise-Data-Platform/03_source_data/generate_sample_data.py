"""
Insurance360 synthetic sample generator.
Generates a small reproducible customer/policy/claim sample locally.
For 10M+ records, extend with chunked generation or Spark-native generation;
do not create one huge in-memory pandas DataFrame.
"""
from pathlib import Path
import csv
import random
from datetime import date, timedelta

OUT = Path("generated")
OUT.mkdir(exist_ok=True)
random.seed(360)

CUSTOMERS = 1000
POLICIES = 2000
CLAIMS = 3000

def write_csv(path, header, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

cities = ["Kolkata", "Delhi", "Patna", "Mumbai", "Bengaluru", "Pune"]
products = ["HEALTH", "LIFE", "MOTOR", "PROPERTY"]
statuses = ["ACTIVE", "LAPSED", "CANCELLED", "EXPIRED"]

customer_rows = []
for i in range(1, CUSTOMERS + 1):
    customer_rows.append([
        f"C{i:07d}", f"Customer_{i}", random.choice(cities),
        random.choice(["INDIVIDUAL", "CORPORATE"]),
        date(2020, 1, 1) + timedelta(days=random.randint(0, 1800))
    ])

policy_rows = []
for i in range(1, POLICIES + 1):
    customer_id = f"C{random.randint(1, CUSTOMERS):07d}"
    start = date(2023, 1, 1) + timedelta(days=random.randint(0, 900))
    policy_rows.append([
        f"P{i:08d}", customer_id, random.choice(products),
        random.choice(statuses), start, start + timedelta(days=365),
        round(random.uniform(5000, 80000), 2), "INR"
    ])

claim_rows = []
for i in range(1, CLAIMS + 1):
    policy_id = f"P{random.randint(1, POLICIES):08d}"
    claim_rows.append([
        f"CL{i:08d}", policy_id,
        random.choice(["INTIMATION", "IN_REVIEW", "APPROVED", "REJECTED", "SETTLED"]),
        round(random.uniform(1000, 250000), 2),
        date(2024, 1, 1) + timedelta(days=random.randint(0, 700))
    ])

write_csv(OUT / "customers.csv",
          ["customer_id", "customer_name", "city", "customer_type", "created_date"],
          customer_rows)
write_csv(OUT / "policies.csv",
          ["policy_id", "customer_id", "product_line", "policy_status",
           "start_date", "end_date", "annual_premium", "currency_code"],
          policy_rows)
write_csv(OUT / "claims.csv",
          ["claim_id", "policy_id", "claim_status", "claimed_amount", "reported_date"],
          claim_rows)

print(f"Generated {len(customer_rows)+len(policy_rows)+len(claim_rows):,} sample rows in {OUT}/")
