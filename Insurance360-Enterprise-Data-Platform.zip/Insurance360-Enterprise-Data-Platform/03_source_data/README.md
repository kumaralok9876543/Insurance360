# Synthetic Source Data

Use synthetic records only. Do not use real customer, policy, claim, medical, financial or employer data.

## Generation strategy

Generate in stages:
- Smoke test: 1,000 rows per core entity.
- Development: 100K total records.
- Scale test: 1M total records.
- Portfolio target: 10M+ total records.

Keep referential integrity by generating parent entities before child entities. Persist a deterministic seed and generation manifest so test runs can be reproduced.

## Required source scenarios

1. Valid records.
2. Duplicate business keys.
3. Required-field nulls.
4. Invalid domain values.
5. Orphan foreign keys.
6. Malformed CSV/JSON records.
7. Schema addition (new nullable column).
8. CDC insert, update and delete.
9. Duplicate CDC event.
10. Out-of-order/late CDC event.
11. Reversal/refund transactions.
12. Currency and date-boundary cases.

## Suggested S3 paths

`s3://<approved-bucket>/<env>/<source>/<entity>/<historical|incremental>/`

Example:
`s3://insurance360-data/dev/claims/claims/historical/`

Never upload millions of tiny files. Generate a manageable number of reasonably sized files and benchmark discovery/processing. The right file size depends on workload and platform.
