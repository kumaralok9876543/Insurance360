# Insurance360 Glossary

| Term | Meaning |
|---|---|
| BRD | Business Requirements Document |
| FRD | Functional Requirements Document |
| CDC | Change Data Capture |
| SCD | Slowly Changing Dimension |
| ETL | Extract, Transform, Load |
| ELT | Extract, Load, Transform |
| DQ | Data Quality |
| SLA | Service Level Agreement |
| RACI | Responsible, Accountable, Consulted, Informed |
| Bronze | Raw/source-aligned lakehouse layer |
| Silver | Cleansed and validated layer |
| Gold | Business-ready layer |
| Auto Loader | Databricks incremental file ingestion capability |
| Checkpoint | Durable streaming progress/state information |
| Schema location | Location used by Auto Loader to track schema information |
| Unity Catalog | Databricks governance/catalog capability |
| External location | Governed reference to cloud storage path |
| Storage credential | Governed identity used to access cloud storage |
| Volume | Governed file storage object in Unity Catalog |
| Reconciliation | Comparison of source and target counts/amounts |
| Quarantine | Isolated invalid records/files for review |
| Idempotency | Repeating an operation does not create unintended additional effects |
| Data mart | Subject-oriented curated dataset for reporting |
| Grain | What one row in a fact table represents |
