# How to Explain Insurance360 in an Interview

## 60-second explanation

"I built Insurance360, a fictional enterprise insurance data platform modernization project using AWS S3 and Databricks. It simulates data from customer, policy, claims, premium, payment and agent systems. I designed a Medallion architecture: historical and incremental source files land in S3; Databricks Auto Loader ingests them into Bronze Delta tables with file and ingestion audit metadata; Silver standardizes, validates, deduplicates and applies CDC; Gold contains policy, claims and finance marts for SQL and Power BI reporting. I also designed source-to-target mappings, ETL reconciliation, negative data-quality scenarios, defect tracking, monitoring and deployment workflows. The data is synthetic and the project is a portfolio simulation."

## Questions you should be able to answer

1. Why use S3 as landing storage?
2. Why use Delta Lake rather than plain files for curated layers?
3. What is the difference between catalog, schema, table and volume?
4. How does Auto Loader discover existing and new files?
5. What is the purpose of schemaLocation vs checkpointLocation?
6. What happens if a checkpoint is deleted?
7. How do you handle schema evolution and incompatible types?
8. How do you guarantee idempotent CDC application?
9. How do you handle late/out-of-order events?
10. How do you reconcile source and target data?
11. What is the grain of each Gold fact table?
12. How do you prevent double counting across claims and payments?
13. How do you optimize Spark jobs and Delta tables?
14. How do you secure S3 and Unity Catalog?
15. How do you recover a failed pipeline?

## Be transparent

Do not claim this was a real client delivery or that you operated Cognizant production systems. Explain which parts you implemented, which were simulated, what scale you actually tested, and measured results only.
