# QA Process and Defect Lifecycle

## Workflow

Requirement review -> test design -> test data preparation -> test execution -> defect logging -> triage -> fix -> retest -> regression -> sign-off.

## Defect states

New -> Triaged -> Assigned -> In Progress -> Fixed -> Ready for Retest -> Retest Passed -> Closed.

If retest fails: Reopened -> Assigned.

## Required defect evidence

- Environment and job/run ID.
- Source file and target table.
- Test case ID.
- Reproducible steps.
- Expected vs actual result.
- Query/output/log evidence.
- Severity, priority and business impact.
- Owner, fix version and retest evidence.

## Release gate

No release with unresolved critical data integrity or security issues. High-severity exceptions require documented risk acceptance by the authorized business/technology owner.
