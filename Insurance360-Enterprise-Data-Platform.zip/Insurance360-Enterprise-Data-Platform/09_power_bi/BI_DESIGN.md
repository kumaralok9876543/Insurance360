# Power BI and Reporting Design

## Semantic model

Recommended star-schema concepts:
- Dimensions: `dim_date`, `dim_customer`, `dim_policy`, `dim_product`, `dim_agent`, `dim_branch`.
- Facts: `fact_policy_lifecycle`, `fact_claims`, `fact_claim_transactions`, `fact_premium_transactions`, `fact_payments`.

Define each fact's grain before relationships/measures. Avoid ambiguous many-to-many joins and double counting.

## Dashboard 1 – Executive Insurance Overview
- Policies issued and active.
- Gross premium billed and collected.
- Outstanding premium.
- Claims registered, approved and settled.
- Claim settlement ratio.
- Trends by product line, region and month.

## Dashboard 2 – Claims Operations
- Claims by status, type, product and region.
- Average claim amount.
- Claim turnaround time.
- Aging of open claims.
- Settlement trend.

## Dashboard 3 – Premium and Finance
- Billed, collected, refunded and outstanding amounts.
- Collection rate.
- Payment failure trend.
- Reconciliation exceptions.
- Currency-aware reporting.

## Dashboard 4 – Policy and Customer
- New policies, renewals, lapses and cancellations.
- Renewal rate.
- Customer distribution by segment and region.
- Product mix.

## Dashboard 5 – Data Operations / QA
- Pipeline success/failure.
- Ingestion freshness.
- Files and rows processed.
- Rejected records.
- Test pass/fail.
- Reconciliation differences.

## KPI governance

Every measure must have:
- Business definition and owner.
- Fact grain and date basis.
- Filter and exclusion rules.
- Currency treatment.
- Numerator/denominator.
- Null/unknown handling.
- Validation SQL and sign-off.
