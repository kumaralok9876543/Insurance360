# Git, CI/CD and Environment Promotion

## Branch strategy

- `main`: approved stable code.
- `develop`: integration branch.
- `feature/<ticket>-<description>`: work item branch.
- `bugfix/<ticket>-<description>`: defect fix branch.
- Pull request requires reviewer, tests and documentation update.

## Promotion model

DEV -> QA -> PROD-like

1. Develop in feature branch.
2. Run lint/unit tests and validate SQL/Python.
3. Open PR and review.
4. Deploy to DEV.
5. Run integration and ETL tests.
6. Promote same artifact/config to QA.
7. Obtain QA/business approval.
8. Promote through controlled release process.
9. Run smoke tests and monitor.

## Configuration

Keep environment-specific paths, catalog names, schema names and job settings in configuration files or approved secret/config systems. Never store credentials in Git.

## Example GitHub Actions outline

A workflow can run repository checks and Python unit tests. Actual Databricks deployment requires selecting a supported deployment method (for example Databricks Asset Bundles / current recommended deployment tooling), configuring secure OIDC or secrets, and adapting to the organization's controls. Do not assume a generic workflow can deploy to every workspace.
