# Insurance360 — Enterprise Insurance Data Platform Modernization

> A fictional, portfolio-grade enterprise simulation covering Business Analysis, Data Architecture, AWS S3, Databricks, PySpark, SQL/ETL development, ETL testing, QA, BI/reporting, DevOps, governance and operations.

**Client:** GlobalSure Insurance Group (fictional)  
**Project:** Insurance360  
**Industry:** Insurance (Health, Life, Motor, Property)  
**Target scale:** 10M+ synthetic records across 28 core business entities, plus operational/audit datasets  
**Cloud and platform:** AWS S3 + Databricks + Delta Lake + Unity Catalog  
**Delivery model:** Agile, role-based department simulation  
**Primary portfolio focus:** Data Engineering + ETL Development

---

## 1. What this project is

GlobalSure's customer, policy, claims, premium, payment, agent, product, underwriting and finance data is distributed across multiple legacy applications. Each application produces files or extracts with different formats, structures, schedules and quality issues. Business teams cannot consistently reconcile premium collections, claims settlement, policy renewals or customer activity.

Insurance360 designs and implements a centralized lakehouse platform:

```text
Legacy source systems
  -> AWS S3 landing/data lake
  -> Databricks Auto Loader / batch ingestion
  -> Bronze Delta (raw + audit)
  -> Silver Delta (standardized, validated, deduplicated, CDC-applied)
  -> Gold marts (business-ready facts/dimensions/aggregates)
  -> SQL / Power BI reporting
```

Cross-functional controls include source-to-target mapping, data contracts, data-quality rules, reconciliation, defect lifecycle, pipeline observability, access control, Git workflows, deployment promotion and operational runbooks.

**Important:** GlobalSure and all data are fictional. This is a learning/portfolio simulation, not a representation of Cognizant or any real client implementation. Do not use real customer or employer data.

## 2. Project goals

1. Consolidate multi-system insurance data into a governed lakehouse.
2. Perform a one-time historical load and repeatable incremental ingestion.
3. Capture lineage/audit metadata (source path, source file, ingestion timestamp, run ID, source system).
4. Handle schema evolution deliberately and safely.
5. Standardize, validate and deduplicate data in Silver.
6. Apply CDC events (insert/update/delete) with deterministic ordering and idempotent processing.
7. Build reusable Gold data marts for policy, claims, premium and finance analytics.
8. Automate ETL testing, reconciliation, QA evidence and defect tracking.
9. Publish trusted KPIs and Power BI dashboards.
10. Operate the platform with monitoring, alerting, recovery, security and CI/CD practices.

## 3. Scope

### In scope
- Health, Life, Motor and Property insurance domains.
- 8 logical source systems and 28 core business entities.
- Synthetic data generation at 10M+ records, scaled in stages.
- CSV, JSON and Parquet source formats.
- AWS S3 landing, archive and quarantine patterns.
- Databricks, PySpark, Spark SQL, Delta Lake and Unity Catalog.
- Historical and incremental ingestion, Auto Loader, checkpoints and schema evolution.
- Bronze, Silver and Gold processing.
- CDC and Delta MERGE.
- Data-quality framework and source-to-target reconciliation.
- BI semantic model, DAX/KPI definitions and dashboard specifications.
- Git-based collaboration, CI/CD simulation, monitoring and runbooks.

### Out of scope for the initial simulation
- Real insurance policy issuance, underwriting decisions or payment processing.
- Live integration with real insurers, banks or payment gateways.
- Real personal, financial, health or claims information.
- Production deployment into a real company's AWS or Databricks account.
- Regulatory/legal certification. Compliance controls are educational design examples only.

## 4. Target scale and performance approach

Target: **10M+ records**, not 10M records in every table. Begin with 100K, validate correctness, then 1M, then 10M+. Measure actual runtime and cost in the selected environment; do not claim a performance SLA until measured.

Recommended engineering principles:
- Process distributed data with Spark; do not collect large datasets to the driver.
- Use Parquet/Delta for analytical storage; retain original source files in landing.
- Avoid excessive tiny files; tune file sizing and compaction based on observed workload.
- Choose partitioning from query and write patterns; do not partition every table or by high-cardinality IDs.
- Use Auto Loader file notification/file events where supported and configured for large-scale discovery.
- Keep one durable checkpoint per independent streaming ingestion.
- Treat checkpoint loss/reset as a recovery event requiring controlled reprocessing and duplicate protection.
- Use `availableNow` for bounded incremental batches; use continuous triggers only when the latency requirement justifies them.
- Use idempotent writes and deterministic keys for safe retries.
- Monitor data volume, file counts, input rates, schema changes, rejected records, freshness and job failures.

## 5. Repository map

```text
01_business_analysis/   BRD, FRD, scope, stories, acceptance criteria
02_architecture/        architecture, ERD, data dictionary, mappings
03_source_data/         synthetic data generator, schemas, test scenarios
04_aws/                 S3 layout, IAM guidance, infrastructure notes
05_databricks/          Bronze/Silver/Gold/Auto Loader/CDC starter code
06_etl_development/     SQL transformations and reusable patterns
07_etl_testing/         test strategy, cases, validation SQL, reconciliation
08_qa/                  test execution, defect workflow, templates
09_power_bi/            semantic model, KPI definitions, dashboard specs
10_devops/              Git, CI/CD, environment promotion, config examples
11_monitoring/          logging, metrics, alerts, runbooks
12_project_management/  roadmap, roles, RACI, sprint ceremonies
13_interview_prep/      project explanation and interview questions
```

## 6. Recommended build sequence

1. Read `01_business_analysis/BRD.md` and `02_architecture/ARCHITECTURE.md`.
2. Approve source entities and business keys in `02_architecture/DATA_DICTIONARY.md`.
3. Complete source-to-target mapping before writing transformations.
4. Generate a small dataset and inspect its schema and relationships.
5. Configure AWS IAM role, Unity Catalog storage credential and external location with an administrator.
6. Verify S3 access and existing catalogs/schemas before creating anything.
7. Create only approved schemas, volumes and tables.
8. Implement Bronze historical ingestion and audit metadata.
9. Implement incremental Auto Loader with stable checkpoint and schema locations.
10. Build Silver cleansing, validation, deduplication and CDC.
11. Build Gold marts and KPI queries.
12. Run ETL tests, reconcile counts/amounts and resolve defects.
13. Build BI reports and operational monitoring.
14. Deploy through controlled DEV -> QA -> PROD-like environments.

## 7. Environment and naming conventions

| Object | Convention | Example |
|---|---|---|
| Catalog | `<org>_<domain>_<env>_ctlg` | `gig_insurance_dev_ctlg` |
| Schema | `bronze`, `silver`, `gold`, `ops` | `gig_insurance_dev_ctlg.bronze` |
| Table | `<entity>[_raw|_clean]` | `claims_raw` |
| Notebook | `<layer>_<source>_<entity>_<purpose>` | `bronze_claims_ingest` |
| Job | `job_<domain>_<layer>_<frequency>` | `job_claims_bronze_daily` |
| S3 prefix | `<env>/<source>/<entity>/<load_type>/` | `dev/claims/claims/historical/` |

These are suggested names for a personal sandbox. In a company workspace, follow existing platform naming standards and reuse approved catalogs/locations. Do not create catalogs, schemas, volumes, credentials or external locations without permission.

## 8. Security and privacy

- Use synthetic data only.
- Never commit AWS access keys, Databricks tokens, passwords or secrets.
- Prefer IAM roles / instance profiles / Unity Catalog storage credentials over hard-coded keys.
- Apply least privilege to S3 paths and Unity Catalog objects.
- Separate DEV, QA and PROD permissions and data.
- Mask or avoid sensitive fields in BI outputs.
- Keep audit and operational logs free of secrets and unnecessary personal data.

## 9. How to use this repository

This repository is an implementation blueprint and starter kit. Cloud-specific resource creation and some Databricks APIs depend on your AWS account, Databricks edition, workspace configuration, Unity Catalog setup and permissions. Follow the official documentation for your current environment before execution.

Start at `12_project_management/IMPLEMENTATION_ROADMAP.md`. Phase 1 is `01_business_analysis/BRD.md` plus `01_business_analysis/CLIENT_KICKOFF.md`.

## 10. Definition of done

A phase is complete only when:
- Its documents/code are committed.
- Acceptance criteria pass.
- Tests and evidence are recorded.
- Data counts and key metrics reconcile.
- Known defects are logged with severity and owner.
- Operational instructions exist.
- No credentials or real sensitive data are committed.

## 11. Official documentation to consult

- Databricks Auto Loader: https://docs.databricks.com/aws/en/ingestion/cloud-object-storage/auto-loader/
- Unity Catalog: https://docs.databricks.com/aws/en/data-governance/unity-catalog/
- Delta Lake: https://docs.databricks.com/aws/en/delta/
- AWS S3: https://docs.aws.amazon.com/AmazonS3/latest/userguide/Welcome.html
- AWS IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/introduction.html
- Power BI: https://learn.microsoft.com/power-bi/

Always validate current product behavior and syntax against the documentation version used by your workspace.
