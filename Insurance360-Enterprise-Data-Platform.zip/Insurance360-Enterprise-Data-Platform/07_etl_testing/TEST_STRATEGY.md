# ETL Testing Strategy

## Test levels

1. Unit: individual transformation functions and business rules.
2. Component: one source entity through Bronze/Silver.
3. Integration: multi-table joins and CDC.
4. Reconciliation: source-to-target counts and financial totals.
5. Regression: previously passing rules remain correct.
6. Performance: staged 100K, 1M and 10M+ workloads.
7. Recovery: failure, retry, checkpoint and replay scenarios.
8. BI validation: dashboard measures reconcile to Gold SQL.

## Core test categories

- Schema and datatype validation.
- Mandatory field / null validation.
- Primary key uniqueness.
- Duplicate detection.
- Foreign key / referential integrity.
- Domain and accepted-value checks.
- Date and timestamp validity.
- Financial amount and currency rules.
- Source-to-target transformation checks.
- CDC insert/update/delete and event ordering.
- Late-arriving and duplicate events.
- Record-count and control-total reconciliation.
- File-level audit and ingestion completeness.
- Error/quarantine routing.
- Incremental idempotency.

## Severity

| Severity | Definition |
|---|---|
| Sev-1 | Data loss, material financial misstatement, security exposure |
| Sev-2 | Major business function/report incorrect or unavailable |
| Sev-3 | Limited data issue with workaround |
| Sev-4 | Cosmetic/documentation issue |

## Exit criteria

- All critical and high tests pass.
- No open Sev-1/Sev-2 defects unless formally accepted.
- Reconciliation within approved tolerance.
- Evidence stored for every test execution.
- Business and QA sign-off captured.
