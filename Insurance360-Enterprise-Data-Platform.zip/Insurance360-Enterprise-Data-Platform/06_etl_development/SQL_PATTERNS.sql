-- 1. Null profiling
SELECT
  COUNT(*) AS total_rows,
  SUM(CASE WHEN customer_id IS NULL THEN 1 ELSE 0 END) AS null_customer_ids
FROM <catalog>.silver.customers;

-- 2. Duplicate business keys
SELECT customer_id, COUNT(*) AS row_count
FROM <catalog>.silver.customers
GROUP BY customer_id
HAVING COUNT(*) > 1;

-- 3. Referential integrity
SELECT COUNT(*) AS orphan_claims
FROM <catalog>.silver.claims c
LEFT ANTI JOIN <catalog>.silver.policies p
  ON c.policy_id = p.policy_id;

-- 4. Window function: latest claim event per claim
WITH ranked AS (
  SELECT *,
         ROW_NUMBER() OVER (
           PARTITION BY claim_id
           ORDER BY event_sequence DESC, event_timestamp DESC
         ) AS rn
  FROM <catalog>.ops.claims_cdc_events
)
SELECT * FROM ranked WHERE rn = 1;

-- 5. Premium collection reconciliation (illustrative)
SELECT
  policy_id,
  SUM(CASE WHEN transaction_type = 'BILL' THEN amount ELSE 0 END) AS billed,
  SUM(CASE WHEN transaction_type = 'COLLECTION' THEN amount ELSE 0 END) AS collected,
  SUM(CASE WHEN transaction_type = 'REFUND' THEN amount ELSE 0 END) AS refunded
FROM <catalog>.silver.premium_transactions
GROUP BY policy_id;
