# Databricks Implementation Guide

## Before creating resources

1. Inspect available catalogs: `SHOW CATALOGS;`
2. Inspect schemas: `SHOW SCHEMAS IN <catalog>;`
3. Inspect external locations and storage credentials through Catalog Explorer or approved admin process.
4. Confirm permissions with the platform owner.
5. Reuse approved catalog/schema/volume where possible.
6. Create new resources only in a personal sandbox or with authorization.

## Suggested logical namespaces

- `<catalog>.bronze`
- `<catalog>.silver`
- `<catalog>.gold`
- `<catalog>.ops`

These are logical design names, not instructions to create them in a corporate workspace.

## Notebook sequence

1. `bronze/01_profile_source.py`
2. `autoloader/02_bronze_historical_incremental.py`
3. `silver/03_standardize_validate.py`
4. `silver/04_cdc_merge.py`
5. `gold/05_build_marts.sql`
6. `ops/06_pipeline_metrics.sql`

## Important implementation note

The sample notebook files are templates. Replace placeholders, configure schemas and permissions, validate source format and runtime compatibility, and run against a small test prefix first.
