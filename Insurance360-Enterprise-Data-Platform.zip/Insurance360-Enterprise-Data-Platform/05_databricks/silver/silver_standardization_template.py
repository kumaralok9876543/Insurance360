# Illustrative Silver standardization template.
from pyspark.sql import functions as F
from pyspark.sql.window import Window

bronze = spark.table("<catalog>.bronze.customers_raw")

typed = (
    bronze
    .withColumn("customer_id", F.trim(F.col("customer_id").cast("string")))
    .withColumn("customer_name", F.trim(F.col("customer_name").cast("string")))
    .withColumn("city", F.upper(F.trim(F.col("city"))))
)

# Example validation flags; business rules must be approved.
validated = (
    typed
    .withColumn("_dq_missing_customer_id", F.col("customer_id").isNull())
    .withColumn("_dq_missing_customer_name", F.col("customer_name").isNull())
)

valid = validated.filter(
    (~F.col("_dq_missing_customer_id")) &
    (~F.col("_dq_missing_customer_name"))
)

invalid = validated.filter(
    F.col("_dq_missing_customer_id") |
    F.col("_dq_missing_customer_name")
)

# Deterministic deduplication requires a trusted source update timestamp/version.
# Replace placeholder ordering with source-defined precedence.
window = Window.partitionBy("customer_id").orderBy(
    F.col("_ingestion_timestamp").desc(),
    F.col("_source_file_path").desc()
)

deduped = (
    valid
    .withColumn("_rn", F.row_number().over(window))
    .filter(F.col("_rn") == 1)
    .drop("_rn")
)

deduped.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(
    "<catalog>.silver.customers"
)

invalid.write.format("delta").mode("append").saveAsTable(
    "<catalog>.ops.customers_quarantine"
)
