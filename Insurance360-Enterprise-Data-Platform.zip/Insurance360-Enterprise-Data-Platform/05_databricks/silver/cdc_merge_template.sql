-- Illustrative current-state CDC merge.
-- Preconditions:
-- 1) Source events are deduplicated to one winning event per business key.
-- 2) event_sequence or another deterministic version is trustworthy.
-- 3) Delete semantics are agreed with the source owner.

MERGE INTO <catalog>.silver.claims AS tgt
USING <catalog>.ops.claims_cdc_deduplicated AS src
ON tgt.claim_id = src.claim_id

WHEN MATCHED
  AND src.event_sequence > tgt.last_event_sequence
  AND src.operation = 'D'
THEN DELETE

WHEN MATCHED
  AND src.event_sequence > tgt.last_event_sequence
  AND src.operation IN ('I', 'U')
THEN UPDATE SET
  tgt.policy_id = src.policy_id,
  tgt.claim_status = src.claim_status,
  tgt.claimed_amount = src.claimed_amount,
  tgt.last_event_sequence = src.event_sequence,
  tgt.last_event_timestamp = src.event_timestamp

WHEN NOT MATCHED
  AND src.operation IN ('I', 'U')
THEN INSERT (
  claim_id, policy_id, claim_status, claimed_amount,
  last_event_sequence, last_event_timestamp
)
VALUES (
  src.claim_id, src.policy_id, src.claim_status, src.claimed_amount,
  src.event_sequence, src.event_timestamp
);
