-- Example only. Confirm business definitions, grain, currency and status logic first.

CREATE OR REPLACE TABLE <catalog>.gold.fact_claims AS
SELECT
    c.claim_id,
    c.policy_id,
    p.customer_id,
    p.product_id,
    c.claim_status,
    c.reported_at,
    c.claimed_amount,
    c.settled_amount,
    c.currency_code
FROM <catalog>.silver.claims c
JOIN <catalog>.silver.policies p
  ON c.policy_id = p.policy_id;

CREATE OR REPLACE TABLE <catalog>.gold.monthly_claims_summary AS
SELECT
    date_trunc('MONTH', reported_at) AS report_month,
    claim_status,
    currency_code,
    COUNT(DISTINCT claim_id) AS claim_count,
    SUM(claimed_amount) AS total_claimed_amount,
    SUM(settled_amount) AS total_settled_amount
FROM <catalog>.gold.fact_claims
GROUP BY date_trunc('MONTH', reported_at), claim_status, currency_code;
