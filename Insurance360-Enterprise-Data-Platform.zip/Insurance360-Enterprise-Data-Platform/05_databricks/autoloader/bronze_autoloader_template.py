# Insurance360 - Auto Loader Bronze ingestion template
# Configure these values for your approved workspace and source entity.

from pyspark.sql import functions as F

SOURCE_PATH = "s3://<approved-bucket>/dev/crm/customers/historical/"
TARGET_TABLE = "<catalog>.bronze.customers_raw"
SCHEMA_LOCATION = "/Volumes/<catalog>/<schema>/<volume>/customers_schema"
CHECKPOINT_LOCATION = "/Volumes/<catalog>/<schema>/<volume>/customers_checkpoint"
SOURCE_FORMAT = "csv"  # csv, json, parquet, etc.

# Prefer an explicit schema/schema hints for production.
# inferColumnTypes is convenient for exploration but can add inference cost/ambiguity.
reader = (
    spark.readStream
         .format("cloudFiles")
         .option("cloudFiles.format", SOURCE_FORMAT)
         .option("cloudFiles.schemaLocation", SCHEMA_LOCATION)
)

if SOURCE_FORMAT == "csv":
    reader = reader.option("header", "true")

# Enable schema evolution only after agreeing the policy with source owners.
reader = reader.option("cloudFiles.schemaEvolutionMode", "addNewColumns")

source_df = reader.load(SOURCE_PATH)

bronze_df = (
    source_df
    .withColumn("_source_file_path", F.col("_metadata.file_path"))
    .withColumn("_source_file_name", F.col("_metadata.file_name"))
    .withColumn("_ingestion_timestamp", F.current_timestamp())
    .withColumn("_source_system", F.lit("CRM"))
)

# availableNow processes currently available data and then terminates.
# Reuse the SAME checkpoint and schema location for this logical stream.
query = (
    bronze_df.writeStream
        .format("delta")
        .outputMode("append")
        .option("checkpointLocation", CHECKPOINT_LOCATION)
        .trigger(availableNow=True)
        .toTable(TARGET_TABLE)
)

query.awaitTermination()

# Production additions:
# - explicit schema/schema hints and rescued-data policy
# - run ID and operational metrics
# - controlled retry/restart in Workflow
# - source inventory and reconciliation
# - alerting and retention
