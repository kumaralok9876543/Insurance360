# Repository File Index

This repository contains the following authored starter documents and templates:

- `.gitignore`
- `01_business_analysis/BRD.md`
- `01_business_analysis/CLIENT_KICKOFF.md`
- `01_business_analysis/FRD.md`
- `01_business_analysis/PROJECT_SCOPE.md`
- `01_business_analysis/USER_STORIES.md`
- `02_architecture/ARCHITECTURE.md`
- `02_architecture/DATA_DICTIONARY.md`
- `02_architecture/ERD.md`
- `02_architecture/SOURCE_TO_TARGET_MAPPING_TEMPLATE.csv`
- `03_source_data/README.md`
- `03_source_data/generate_sample_data.py`
- `04_aws/S3_LAYOUT_AND_IAM.md`
- `05_databricks/README.md`
- `05_databricks/autoloader/bronze_autoloader_template.py`
- `05_databricks/gold/build_gold_marts.sql`
- `05_databricks/silver/cdc_merge_template.sql`
- `05_databricks/silver/silver_standardization_template.py`
- `06_etl_development/SQL_PATTERNS.sql`
- `07_etl_testing/RECONCILIATION_TEMPLATE.csv`
- `07_etl_testing/TEST_CASES.csv`
- `07_etl_testing/TEST_STRATEGY.md`
- `08_qa/DEFECT_LOG_TEMPLATE.csv`
- `08_qa/QA_PROCESS.md`
- `09_power_bi/BI_DESIGN.md`
- `10_devops/GIT_AND_CICD.md`
- `11_monitoring/OBSERVABILITY.md`
- `12_project_management/IMPLEMENTATION_ROADMAP.md`
- `12_project_management/RACI.csv`
- `13_interview_prep/PROJECT_WALKTHROUGH.md`
- `13_interview_prep/TERMS_GLOSSARY.md`
- `LICENSE`
- `README.md`
