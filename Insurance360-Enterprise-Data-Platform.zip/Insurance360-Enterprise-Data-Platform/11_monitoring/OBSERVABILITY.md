# Monitoring, Audit and Operations

## Pipeline run log fields

- `run_id`
- `job_name`
- `source_system`
- `entity`
- `source_path`
- `target_table`
- `start_timestamp`
- `end_timestamp`
- `status`
- `files_discovered`
- `files_processed`
- `rows_read`
- `rows_written`
- `rows_rejected`
- `error_code`
- `error_message` (sanitized)
- `code_version`

## Metrics

- Job success rate and duration.
- Source-to-target freshness.
- Files discovered vs processed.
- Rows read/written/rejected.
- Duplicate and null rates.
- Schema drift events.
- CDC lag and late-event counts.
- Reconciliation difference.
- Delta file count and table size.
- Cost/compute usage where available.

## Alert examples

- Job failed.
- No expected file arrived by deadline.
- Row count deviates from baseline threshold.
- Rejected-row percentage exceeds threshold.
- Schema change detected.
- Premium/payment reconciliation difference exceeds tolerance.
- Data freshness SLA breached.

## Operational runbooks

### Failed ingestion
1. Capture run ID and error.
2. Check source path and permissions.
3. Inspect schema evolution/rescued data.
4. Verify checkpoint remains intact.
5. Fix root cause.
6. Retry using the same checkpoint unless a documented rebuild plan says otherwise.
7. Reconcile output and record incident.

### Checkpoint loss
1. Stop the affected job.
2. Do not blindly create a new checkpoint against the same target.
3. Identify processed source files and target state.
4. Decide controlled replay, deduplication or target rebuild.
5. Use a new checkpoint only as part of approved recovery.
6. Reconcile and document.

### Data quality incident
1. Identify affected entity, partition/time range and downstream reports.
2. Quarantine affected records.
3. Notify data owner and BI consumers.
4. Correct source or transformation.
5. Replay/reprocess safely.
6. Run regression and reconcile.
