# Functional Requirements Document (FRD)

## 1. Processing overview

Each source entity follows a controlled path:

1. Source owner publishes an extract or CDC file.
2. File lands in the designated S3 prefix.
3. Ingestion job discovers and reads the file.
4. Bronze stores source-shaped records plus technical metadata.
5. Silver standardizes types, validates records, deduplicates and applies CDC.
6. Gold creates facts, dimensions and aggregates.
7. Tests reconcile counts, keys and amounts.
8. BI consumes approved Gold tables.

## 2. Source ingestion requirements

- Each entity has a configuration entry: source path, format, delimiter/header, schema location, checkpoint location, target table, expected keys and load mode.
- Historical and incremental ingestion are separately identifiable.
- Auto Loader uses a durable schema location and a durable checkpoint location.
- Checkpoints are not shared by independent streams.
- `availableNow` is the default for scheduled bounded ingestion; continuous processing is selected only for a justified latency requirement.
- Source file metadata is captured using supported file metadata columns.
- The source file is not deleted as part of successful ingestion; retention/archive is a separately governed lifecycle step.
- Failed files and malformed records are observable and recoverable.

## 3. Bronze functional requirements

- Preserve source fields with minimal business transformation.
- Add `_source_system`, `_source_file_path`, `_source_file_name`, `_ingestion_timestamp`, `_ingestion_run_id`, `_record_hash` where appropriate.
- Retain raw payload or rescued data for schema issues where supported by source format.
- Use Delta append for immutable file-arrival events; define deduplication/replay strategy.
- Store ingestion metrics in operational tables.

## 4. Silver functional requirements

- Normalize column names, data types, timestamps, codes and currency fields.
- Apply required-field and domain checks.
- Deduplicate by business key using source update timestamp, event sequence and deterministic tie-breakers.
- Separate valid and invalid records.
- Apply CDC only when event ordering and delete semantics are understood.
- Maintain current-state tables and, where required, history/SCD2 tables.
- Make transformations idempotent.

## 5. Gold functional requirements

- Build conformed dimensions: customer, policy, product, agent, branch, date.
- Build facts: policy lifecycle, claims, claim transactions, premium transactions, payments.
- Create aggregates for executive, claims, policy and finance reporting.
- Document grain, measures, dimensions, refresh frequency and filters.

## 6. Operational requirements

- Every run has a unique run ID, start/end timestamps, status, input/output counts and error summary.
- Alerts are raised for failed runs, freshness breaches, unexpected volume changes and quality threshold breaches.
- Rerun instructions identify whether to restart from checkpoint, replay a source range or rebuild a target.
- DEV, QA and PROD-like configurations are parameterized.
- Deployment includes code review and test evidence.

## 7. Error handling

| Error class | Required action |
|---|---|
| Access denied | Fail fast, log path/identity, request correct permission |
| Missing source path | Mark source unavailable; do not silently create empty target |
| Malformed record | Capture rescued/bad record and quarantine with reason |
| Schema addition | Apply approved evolution and restart/retry as required |
| Incompatible type | Quarantine or explicit cast policy; alert owner |
| Duplicate business key | Apply documented precedence rule or quarantine |
| Late CDC event | Compare event version/order; do not overwrite newer state |
| Target write failure | Fail job, preserve checkpoint and investigate before replay |

## 8. Functional acceptance tests

- Existing historical files are discovered on first run.
- Re-running with the same checkpoint does not reprocess completed files as new arrivals.
- New files are ingested on a later run.
- Added columns are handled under approved schema policy.
- Invalid records are observable and excluded from trusted Gold metrics.
- CDC update/delete cases produce expected current state.
- Reconciliation outputs match expected counts and amounts.
