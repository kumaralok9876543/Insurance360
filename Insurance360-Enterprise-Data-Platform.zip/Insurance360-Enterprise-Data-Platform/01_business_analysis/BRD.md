# Business Requirements Document (BRD)

| Attribute | Value |
|---|---|
| Project | Insurance360 |
| Client | GlobalSure Insurance Group (fictional) |
| Version | 1.0 – baseline draft |
| Status | For simulated stakeholder review |
| Owner | Business Analyst |
| Sponsor | Chief Data & Analytics Officer (fictional) |

## 1. Executive summary

GlobalSure operates Health, Life, Motor and Property insurance products. Customer, policy, claims, premium, payment, agent and underwriting information is held in multiple operational systems. Data formats and refresh schedules vary. This creates inconsistent reporting, manual reconciliation, slow analysis and limited visibility into data quality.

Insurance360 will build a centralized AWS S3 + Databricks lakehouse. Historical and incremental data will be ingested, standardized, quality-checked and curated into Gold marts for business reporting.

## 2. Business problem

- Data is fragmented across operational applications.
- Business reports use inconsistent definitions and extracts.
- Premium billed, collected, refunded and outstanding amounts are not consistently reconciled.
- Claims status and settlement metrics require manual consolidation.
- Duplicate and incomplete records reduce trust.
- Schema changes and late-arriving records are difficult to manage.
- Pipeline failures and data-quality issues lack consistent audit trails.

## 3. Business objectives

| ID | Objective | Success evidence |
|---|---|---|
| BO-01 | Centralize priority insurance data | Approved entities available in governed lakehouse |
| BO-02 | Migrate history | Source-to-target count and amount reconciliation |
| BO-03 | Enable incremental refresh | New/changed records processed without full reload |
| BO-04 | Improve trust | Quality rules and exception reporting |
| BO-05 | Support claims/premium analytics | Approved Gold marts and KPI definitions |
| BO-06 | Improve traceability | File, run, timestamp and source metadata |
| BO-07 | Operationalize delivery | Monitoring, recovery and deployment runbooks |

## 4. Stakeholders

| Stakeholder | Responsibility / interest |
|---|---|
| Executive sponsor | Funding, priorities and acceptance |
| Insurance operations head | Policy lifecycle and operational metrics |
| Claims manager | Claim intake, approval and settlement |
| Finance head | Premium, payment, refund and reconciliation |
| Product owner | Backlog and business priority |
| Business analyst | Requirements, definitions and acceptance criteria |
| Data architect | Target architecture and data model |
| Data engineering lead | Ingestion, transformation and platform quality |
| ETL developer | Source-to-target transformation logic |
| ETL test lead | Data validation and reconciliation |
| QA lead | Test execution, defects and release readiness |
| BI developer | Semantic model and dashboards |
| DevOps/platform engineer | Access, CI/CD, environment and operations |

## 5. Business requirements

| ID | Requirement | Priority |
|---|---|---|
| BR-001 | Ingest customer master and related contact/address data | Must |
| BR-002 | Ingest policy, coverage, beneficiary and renewal data | Must |
| BR-003 | Ingest claims, transactions, reserves and status history | Must |
| BR-004 | Ingest premium, payment, refund and commission data | Must |
| BR-005 | Ingest agent, branch, product and underwriting reference data | Should |
| BR-006 | Support full historical load | Must |
| BR-007 | Support incremental file ingestion | Must |
| BR-008 | Capture source path, file name, source system, ingestion timestamp and run ID | Must |
| BR-009 | Detect schema additions and route incompatible data for review | Must |
| BR-010 | Standardize formats, data types, codes and timestamps | Must |
| BR-011 | Deduplicate using documented business keys and precedence rules | Must |
| BR-012 | Apply CDC insert/update/delete events | Must |
| BR-013 | Preserve required history for audit and analysis | Should |
| BR-014 | Validate primary keys, nulls, domains and referential integrity | Must |
| BR-015 | Reconcile source and target counts and financial amounts | Must |
| BR-016 | Quarantine invalid records with reason codes | Must |
| BR-017 | Publish policy, claims, premium and finance marts | Must |
| BR-018 | Publish approved business KPIs and dashboards | Must |
| BR-019 | Log pipeline runs, failures, duration and data volumes | Must |
| BR-020 | Support reruns and recovery without uncontrolled duplicates | Must |

## 6. Non-functional requirements

- Scalability: initial synthetic target exceeds 10 million records; capacity to scale further.
- Reliability: retries, checkpoint persistence, idempotent processing and recovery procedures.
- Performance: benchmark using agreed workload; no unmeasured SLA claims.
- Security: least-privilege IAM and Unity Catalog permissions.
- Auditability: trace source-to-target data and pipeline execution.
- Maintainability: modular notebooks, reusable functions, configuration-driven jobs.
- Portability: parameterized environment configuration; no secrets in source control.
- Data quality: automated rules, thresholds and exception visibility.
- Availability/freshness: define per dataset in the service-level objectives before production simulation.

## 7. Scope and exclusions

See `PROJECT_SCOPE.md`.

## 8. Business KPI definitions (initial)

| KPI | Initial definition | Notes requiring stakeholder agreement |
|---|---|---|
| Policies issued | Count of distinct policy IDs issued in selected period | Define issue date and cancellations |
| Active policies | Policies effective on as-of date and not terminated/cancelled | Define grace period and reinstatement |
| Gross premium billed | Sum of billed premium transactions | Currency and reversals |
| Premium collected | Sum of successful collection transactions | Exclude failed/reversed payments |
| Outstanding premium | Billed less allocated successful collections and credits | Allocation and aging rules |
| Claims registered | Count of distinct claims by registered date | Reopened claims |
| Approved claims | Claims with approved status as of date | Status history precedence |
| Settled claims | Claims with settlement completed | Partial settlements |
| Claim settlement ratio | Settled eligible claims / eligible claims | Define cohort and denominator |
| Average claim amount | Approved/settled amount divided by eligible claim count | Select gross/net amount |
| Renewal rate | Renewed policies / policies eligible for renewal | Renewal window and exclusions |
| Claim turnaround time | Settlement timestamp minus registration timestamp | Business calendar and reopened claims |

No KPI is final until the business owner signs off its exact filters, date basis, currency treatment and denominator.

## 9. Assumptions and dependencies

- Source extracts can be delivered to approved S3 paths.
- Source owners provide schemas, key definitions and CDC semantics.
- AWS and Databricks administrators provision required permissions.
- Databricks workspace supports Unity Catalog and required Auto Loader features.
- Synthetic datasets are used for portfolio development.
- Power BI connectivity/licensing is available for the BI phase.

## 10. Risks

| Risk | Impact | Mitigation |
|---|---|---|
| Missing source keys | Incorrect joins/deduplication | Source profiling and agreed key rules |
| Schema drift | Pipeline failure or bad typing | Schema tracking, rescued data, alerts and review |
| Duplicate/late events | Incorrect current state | Event ordering, idempotency and replay tests |
| Small-file explosion | Poor performance | File sizing, compaction and file-event discovery |
| Checkpoint loss | Reprocessing/duplicates | Durable storage, recovery runbook and idempotent sink |
| Cost overrun | Unplanned cloud spend | Budgets, auto-termination, staged scale tests |
| Unclear KPI definitions | Conflicting reports | Business sign-off and semantic definitions |

## 11. Acceptance criteria

- All in-scope source entities have approved schemas and business keys.
- Historical load completes and reconciles within agreed tolerance.
- Incremental load handles new files and CDC test events.
- Audit metadata is populated and traceable.
- Quality rules produce pass/fail and quarantine outcomes.
- Gold marts reproduce approved KPI definitions.
- Dashboard totals reconcile to Gold queries.
- Runbooks and deployment instructions are reviewed.
