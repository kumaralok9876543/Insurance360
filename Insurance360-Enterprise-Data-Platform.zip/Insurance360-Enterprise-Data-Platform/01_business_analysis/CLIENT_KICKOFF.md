# Simulated Client Kick-off Meeting

**Client:** GlobalSure Insurance Group (fictional)  
**Project:** Insurance360  
**Meeting type:** Discovery / project initiation

## Client statement

"Our insurance data is distributed across multiple legacy applications. Customer, policy, claims, premium and payment reporting is slow and inconsistent. We want a centralized AWS and Databricks lakehouse that supports historical migration, daily incremental updates, data quality, CDC and management reporting."

## Questions the project team must ask

### Business
1. Which products and geographies are in scope?
2. What does an active policy mean?
3. What qualifies as a settled claim?
4. How are premium reversals, refunds and partial payments treated?
5. Which KPIs are executive priorities?

### Source systems
1. What is the owner and refresh schedule for each source?
2. What are the primary/business keys?
3. Are CDC operation codes and event ordering available?
4. What are the timestamp time zones?
5. What file formats, encodings and delimiters are used?

### Platform and security
1. Is Unity Catalog enabled?
2. Which catalog/schema/external locations already exist?
3. Which IAM role and S3 prefixes are approved?
4. Who owns storage credentials and external locations?
5. What data retention and access restrictions apply?

### Testing and operations
1. What are source count/amount control totals?
2. What tolerance is acceptable for reconciliation?
3. What freshness target is required?
4. Who approves QA and production release?
5. What is the recovery/replay policy?

## Decisions register

| Decision ID | Decision | Owner | Status |
|---|---|---|---|
| DEC-001 | Use synthetic data for portfolio implementation | Project lead | Approved |
| DEC-002 | Use AWS S3 + Databricks lakehouse | Architecture | Proposed |
| DEC-003 | Use 10M+ staged scale | Engineering | Proposed |
| DEC-004 | KPI definitions require business sign-off | Business owner | Open |
| DEC-005 | Use existing company resources where applicable; do not create unauthorized resources | Platform owner | Approved |
