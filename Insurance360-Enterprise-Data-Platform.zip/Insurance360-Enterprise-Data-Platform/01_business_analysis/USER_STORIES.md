# User Stories and Acceptance Criteria

| ID | As a... | I want... | So that... |
|---|---|---|---|
| US-001 | Data engineer | To ingest historical source files | Legacy history is centralized |
| US-002 | Data engineer | To process only new files on scheduled runs | Reprocessing is avoided |
| US-003 | Data engineer | To capture file and run metadata | Data lineage is traceable |
| US-004 | Data engineer | To detect schema additions | New source attributes are managed |
| US-005 | ETL developer | To standardize customer and policy fields | Downstream data is consistent |
| US-006 | ETL developer | To apply ordered CDC events | Current-state tables stay correct |
| US-007 | ETL tester | To compare source and target counts | Completeness is validated |
| US-008 | ETL tester | To reconcile premium/payment amounts | Financial totals are trusted |
| US-009 | QA engineer | To log, assign and retest defects | Releases are controlled |
| US-010 | BI developer | To consume certified Gold marts | Reports use trusted data |
| US-011 | Operations engineer | To monitor job health and freshness | Failures are detected early |
| US-012 | Platform engineer | To promote tested code across environments | Releases are repeatable |

## Example acceptance criteria – US-002
- Given a checkpointed Auto Loader stream has processed the existing files,
- When a new file is added to the configured source prefix,
- Then the next scheduled run discovers and processes the new file,
- And previously completed files are not treated as new arrivals,
- And input/output metrics are recorded,
- And a rerun after failure follows the documented recovery procedure.
