# Project Scope and Delivery Boundaries

## In scope
- Four insurance product lines: Health, Life, Motor, Property.
- Eight logical source domains.
- 28 core entities listed in the data dictionary.
- Synthetic data at staged scale: 100K -> 1M -> 10M+.
- AWS S3 landing and Databricks Delta lakehouse.
- Historical, incremental and CDC scenarios.
- Bronze/Silver/Gold, data quality, reconciliation and BI.
- Role-based department simulation.

## Out of scope
- Real customer data and live production systems.
- Real claims adjudication or underwriting decisions.
- Payment gateway integration.
- Regulatory certification or legal advice.
- Unbounded 10M-record load before cost/performance checks.

## Definition of success
- End-to-end lineage from source file to Gold output.
- Repeatable historical and incremental loads.
- Documented schema evolution and checkpoint recovery.
- Silver quality gates and CDC correctness.
- Gold KPIs reconciled to approved definitions.
- ETL and QA evidence, defects and release sign-off.
- Deployable code and documentation with no secrets committed.
