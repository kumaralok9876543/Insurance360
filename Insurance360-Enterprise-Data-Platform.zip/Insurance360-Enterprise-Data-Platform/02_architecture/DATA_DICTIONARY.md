# Core Data Dictionary (28 Entities)

All data is synthetic. IDs are strings unless otherwise noted. Timestamps are stored in UTC. Monetary amounts use `DECIMAL(18,2)` and require an associated currency code. The exact field-level schema is refined during source profiling.

| Domain | Entity | Primary key | Important attributes | Grain |
|---|---|---|---|---|
| Customer | customers | customer_id | customer_type, status, created_at, updated_at | One customer |
| Customer | customer_addresses | address_id | customer_id, address_type, city, state, country | One address |
| Customer | customer_contacts | contact_id | customer_id, contact_type, contact_value, is_primary | One contact |
| Customer | customer_documents | document_id | customer_id, document_type, verification_status | One document |
| Policy | policies | policy_id | customer_id, product_id, agent_id, policy_status, start_date, end_date | One policy |
| Policy | policy_versions | version_id | policy_id, version_number, effective_at, change_type | One policy version |
| Policy | policy_coverage | coverage_id | policy_id, coverage_code, limit_amount, deductible | One coverage per policy |
| Policy | policy_beneficiaries | beneficiary_id | policy_id, beneficiary_type, allocation_pct | One beneficiary |
| Policy | policy_renewals | renewal_id | policy_id, renewal_due_date, renewal_status | One renewal event |
| Claims | claims | claim_id | policy_id, claim_type, reported_at, claim_status, claimed_amount | One claim |
| Claims | claim_transactions | transaction_id | claim_id, transaction_type, amount, transaction_at | One claim financial event |
| Claims | claim_reserves | reserve_id | claim_id, reserve_amount, effective_at | One reserve event |
| Claims | claim_documents | claim_document_id | claim_id, document_type, received_at | One claim document |
| Claims | claim_adjusters | assignment_id | claim_id, adjuster_id, assigned_at | One assignment |
| Claims | claim_status_history | status_history_id | claim_id, old_status, new_status, event_at | One status transition |
| Finance | premium_accounts | premium_account_id | policy_id, billing_frequency, account_status | One premium account |
| Finance | premium_transactions | premium_txn_id | policy_id, transaction_type, amount, transaction_at | One premium event |
| Finance | payment_transactions | payment_id | premium_account_id, payment_status, amount, paid_at | One payment |
| Finance | refunds | refund_id | payment_id, refund_amount, refund_status, refund_at | One refund |
| Finance | commissions | commission_id | policy_id, agent_id, commission_amount, earned_at | One commission |
| Distribution | agents | agent_id | branch_id, agent_status, appointment_date | One agent |
| Distribution | agent_branches | branch_assignment_id | agent_id, branch_id, start_date, end_date | One assignment |
| Distribution | agent_performance | performance_id | agent_id, period_month, policies_sold, premium_sold | One agent-period |
| Product | insurance_products | product_id | product_name, product_line, product_status | One product |
| Product | product_coverage | product_coverage_id | product_id, coverage_code, default_limit | One product coverage |
| Underwriting | underwriting_assessments | assessment_id | policy_id, risk_category_id, decision, assessed_at | One assessment |
| Reference | risk_categories | risk_category_id | risk_code, risk_description | One risk category |
| Reference | branches | branch_id | branch_name, region, country | One branch |
| Reference | currencies | currency_code | currency_name, decimal_places | One currency |

**Count note:** The listed inventory contains 29 entities when all rows are counted. The project target is therefore **29 core entities**, not 28. Confirm exact scope before generating all data.

## Core relationship rules

- `policies.customer_id` references `customers.customer_id`.
- `policies.product_id` references `insurance_products.product_id`.
- `policies.agent_id` references `agents.agent_id`.
- `claims.policy_id` references `policies.policy_id`.
- `claim_transactions.claim_id` references `claims.claim_id`.
- `premium_transactions.policy_id` references `policies.policy_id`.
- `payment_transactions.premium_account_id` references `premium_accounts.premium_account_id`.
- `premium_accounts.policy_id` references `policies.policy_id`.
- `underwriting_assessments.policy_id` references `policies.policy_id`.
- All foreign-key rules are validated in Silver; source defects are not silently discarded.

## CDC envelope (recommended)

| Field | Description |
|---|---|
| `business_key` | Source entity key |
| `operation` | I/U/D or agreed source code |
| `event_timestamp` | Source event time |
| `event_sequence` | Monotonic source ordering, if available |
| `source_system` | Originating system |
| `payload` | Changed attributes or full after-image |
| `file_name` | File carrying the event |

Do not implement production CDC until source semantics (full after-image vs partial update, delete representation, ordering guarantees) are confirmed.
