# Solution Architecture

## 1. Logical architecture

```text
Source applications
  |  scheduled extracts / CDC files
  v
AWS S3 landing
  |  Auto Loader (cloudFiles) / batch
  v
Bronze Delta (source-shaped + technical metadata)
  |  Spark SQL / PySpark
  v
Silver Delta (typed, standardized, quality-checked, CDC-applied)
  |  dimensional modeling / aggregation
  v
Gold Delta marts
  |  SQL Warehouse / Power BI
  v
Business reports and dashboards
```

## 2. Storage zones

| Zone | Purpose | Example |
|---|---|---|
| Landing | Immutable source arrival | `s3://.../dev/claims/historical/` |
| Archive | Retained source files | `s3://.../archive/claims/` |
| Quarantine | Rejected files/records | `s3://.../quarantine/claims/` |
| Bronze | Raw Delta representation | `catalog.bronze.claims_raw` |
| Silver | Trusted entity-level data | `catalog.silver.claims` |
| Gold | Business marts | `catalog.gold.fact_claims` |
| Ops | Run logs and quality metrics | `catalog.ops.pipeline_run_log` |

## 3. Unity Catalog hierarchy

`catalog.schema.table`

- Catalog: top-level governance namespace, often aligned to domain/environment.
- Schema: groups tables, views, volumes and functions (for example bronze/silver/gold/ops).
- Table: governed data object.
- Volume: governed file storage location for non-tabular files, such as schema metadata or checkpoint directories when supported and appropriate.

Do not create a new catalog just because a project starts. Inspect existing catalogs, schemas, external locations and permissions first. In an enterprise workspace, platform administrators commonly own metastore, storage credential and external location setup. Follow the organization's standards.

## 4. AWS access pattern

Preferred pattern:
1. AWS administrator creates a least-privilege IAM role/policy for the required bucket/prefix.
2. Databricks platform administrator configures a Unity Catalog storage credential using the supported AWS role trust relationship.
3. Administrator creates an external location for the approved S3 prefix.
4. Grants appropriate privileges to the project principal/group.
5. Engineer verifies access with a small read/list test.

Avoid hard-coded AWS access keys. Exact steps differ by workspace/account and should follow current Databricks AWS documentation.

## 5. Ingestion patterns

### Historical load
- Define the historical source prefix and file format.
- Use Auto Loader with existing-file discovery, or a controlled batch read where appropriate.
- Use stable schema location and checkpoint location.
- Use `availableNow` for bounded processing.
- Reconcile source file inventory and row counts.

### Incremental load
- New files arrive in a controlled landing prefix.
- Reuse the same source identity, schema location and checkpoint for that stream.
- Schedule a Workflow job.
- Ensure source file naming/arrival semantics are reliable.
- Never delete or replace checkpoint directories casually.

### CDC
- Require a business key, operation type, event timestamp and preferably monotonic source sequence/version.
- Deduplicate multiple events per key using deterministic ordering.
- Apply only events newer than the target version.
- Handle deletes using tombstones or explicit delete logic.
- Test out-of-order, duplicate and late-arriving events.

## 6. Medallion design

### Bronze
Source-aligned, minimally transformed, append-oriented. Capture metadata and preserve evidence of what arrived.

### Silver
Typed and standardized entities; quality rules; deduplication; reference integrity; CDC; invalid records separated from trusted records.

### Gold
Business facts/dimensions and aggregates. Every measure has a documented grain and KPI definition.

## 7. Resilience and idempotency

- Checkpoint tracks source progress for a streaming query.
- A checkpoint is durable state, not a disposable cache.
- A new checkpoint can cause source rediscovery/reprocessing.
- Delta transactions provide atomic table commits, but end-to-end exactly-once claims depend on the complete source, checkpoint and sink design.
- Use stable business keys, event versions, deduplication and idempotent merge logic.
- For full rebuilds, use a separate controlled checkpoint and target strategy.

## 8. Scale and performance

- Use file events for high-volume file discovery where supported.
- Tune `cloudFiles.maxFilesPerTrigger` / `cloudFiles.maxBytesPerTrigger` based on throughput and cluster capacity.
- Avoid `inferColumnTypes` at scale when a governed explicit schema is available.
- Use schema hints or explicit schemas for predictable types.
- Optimize Delta tables based on actual query patterns and platform capabilities.
- Use liquid clustering or partitioning only when justified by workload and supported by the runtime.
- Monitor shuffle, skew, spill, file counts, small files and job duration.
