# ERD – Main Insurance Relationships

```mermaid
erDiagram
  CUSTOMERS ||--o{ POLICIES : owns
  CUSTOMERS ||--o{ CUSTOMER_ADDRESSES : has
  CUSTOMERS ||--o{ CUSTOMER_CONTACTS : has
  INSURANCE_PRODUCTS ||--o{ POLICIES : selected_for
  AGENTS ||--o{ POLICIES : sells
  BRANCHES ||--o{ AGENTS : contains
  POLICIES ||--o{ POLICY_COVERAGE : includes
  POLICIES ||--o{ POLICY_VERSIONS : changes
  POLICIES ||--o{ POLICY_RENEWALS : renews
  POLICIES ||--o{ CLAIMS : receives
  CLAIMS ||--o{ CLAIM_TRANSACTIONS : has
  CLAIMS ||--o{ CLAIM_STATUS_HISTORY : tracks
  CLAIMS ||--o{ CLAIM_RESERVES : reserves
  POLICIES ||--o{ PREMIUM_ACCOUNTS : billed_through
  PREMIUM_ACCOUNTS ||--o{ PAYMENT_TRANSACTIONS : receives
  POLICIES ||--o{ PREMIUM_TRANSACTIONS : generates
  POLICIES ||--o{ UNDERWRITING_ASSESSMENTS : assessed
  RISK_CATEGORIES ||--o{ UNDERWRITING_ASSESSMENTS : classifies
```

This is a logical model. Physical types, optionality, cardinality and source-specific keys must be confirmed from profiling and business owners.
