# AWS S3 Layout and IAM Design

## S3 prefix layout

```text
s3://insurance360-data/
  dev/
    crm/customers/historical/
    crm/customers/incremental/
    policy/policies/historical/
    policy/policies/incremental/
    claims/claims/historical/
    claims/claims/incremental/
    finance/payments/historical/
    finance/payments/incremental/
  qa/
  prod/
  archive/
  quarantine/
```

## Access model

Use an IAM role and Unity Catalog storage credential / external location where supported. Grant only the required bucket and prefix actions. Separate read access to landing from write access to archive/quarantine if those processes are used.

Typical capabilities to evaluate with the AWS/platform administrator:
- List bucket/prefix.
- Read objects from landing prefixes.
- Write objects only to approved archive/quarantine prefixes if required.
- Read/write access to the exact external location used by the workflow.

Do not copy generic IAM policy JSON into production without adapting bucket ARN, prefix, trust relationship, encryption and organization controls.

## Databricks setup checklist

1. Confirm Unity Catalog is enabled.
2. Inspect existing catalogs, storage credentials and external locations.
3. Ask platform admin to create/configure role trust and storage credential if not present.
4. Ask admin to create approved external location.
5. Grant project group only necessary privileges.
6. Test list/read access on a small non-sensitive sample.
7. Record owner, bucket/prefix, privileges and approval ticket in the project documentation.

## Safety

Never place AWS access keys in notebooks, GitHub, CSV files or screenshots. Use secret scopes only when a supported integration genuinely requires a secret; prefer role-based access.
